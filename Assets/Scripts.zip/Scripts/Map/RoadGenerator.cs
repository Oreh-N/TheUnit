﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace MapSpace
{
	using MNames = Map.MapNames;


	/// <summary>
	/// Simple road generator. Doesn't see obstacles. Not optimized. 
	/// Call only at the very beggining of the game, because taking too much time.
	/// </summary>
	public static class RoadGenerator
	{
		const int roadWidth = 30;


		/// <summary>
		/// Generates roads from each base to the center of the map.
		/// </summary>
		public static void GenRoadsBetweenAllTeams(Vector2Int map_size)
		{
			var mapCenter = new Vector2Int(map_size.x / 2, map_size.y / 2);
			IReadOnlyCollection<IReadOnlyTeam> ts = MainController.Instance.GetAllTeams();
			foreach (var t in ts)
			{
				if (t == null) continue;
				var baseCenter = new Vector2Int((int)t.GetTeamCenter().x, (int)t.GetTeamCenter().z);
				SignRoadOnMap(baseCenter, mapCenter);
			}
		}

		/// <summary>
		/// Assignes road on map from start to end
		/// </summary>
		/// <param name="start"> - start coordinates on map</param>
		/// <param name="end"> - end coordinates on map</param>
		static void SignRoadOnMap(Vector2Int start, Vector2Int end)
		{
			List<Vector2Int> road = GetShortestRoad(start, end);

			foreach (var part in road)
			{
				Vector2Int dir = new Vector2Int(
					Math.Sign(end.x - part.x),
					Math.Sign(end.y - part.y)
				);
				Vector2Int perpDir = new Vector2Int(-dir.y, dir.x);
				WidenRoad(part, roadWidth, perpDir);
			}
		}

		static Vector2Int GetClosestDir(Vector2Int curr, Vector2Int goal)
		{
			Vector2Int closest_dir = new Vector2Int(0, 0);

			for (int x = -1; x <= 1; x++)
				for (int y = -1; y <= 1; y++)
				{
					var dir = new Vector2Int(x, y);
					if (Vector2Int.Distance(curr + dir, goal) <
						Vector2Int.Distance(curr + closest_dir, goal))
					{ closest_dir = dir; }
				}

			return closest_dir;
		}

		static List<Vector2Int> GetShortestRoad(Vector2Int start, Vector2Int end)
		{
			List<Vector2Int> road = new List<Vector2Int>();
			var curr = start;
			while (!IsClose(curr, end, roadWidth / 2))
			{
				Vector2Int dir = GetClosestDir(curr, end);
				curr = curr + dir;
				road.Add(curr);
			}
			return road;
		}

		static bool IsClose(Vector2Int curr, Vector2Int goal, int goal_radius = 50)
		{
			return Vector2Int.Distance(curr, goal) < goal_radius;
		}

		static void WidenRoad(Vector2Int center, int width, Vector2Int perpDir)
		{
			int r = width / 2;

			for (int x = -r; x <= r; x++)
				for (int y = -r; y <= r; y++)
				{
					if (x * x + y * y > r * r)
						continue;
					SetRoadOnPosition(new Vector2Int(center.x + x, center.y + y));
				}
		}

		static public void SetRoadOnPosition(Vector2Int coord)
		{
			if (Map.IsOutOfMap(coord)) return;

			Map.TrySetCell(MNames.EnvMap, coord, Map.CellType.Road);
		}
	}
}
