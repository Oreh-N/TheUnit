using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class TreeScript : LootHolder, IMyPlaceableOnMap
{
	public Vector3 GetPos()
	{
		return transform.position;
	}

	public Vector2Int GetSize()
	{
		return new Vector2Int(1, 1);
	}

	private void Awake()
	{
		inventory.FillFully(LootType.Wood);
	}

	private new void Update()
	{
		base.Update();
	}

}
