using MapSpace;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UIElements;
using static UnityEditor.PlayerSettings;


// Visuals should be separated from logic
/// <summary>
/// Centralize data about each specific team, and contains method to control it (mining, attack)
/// </summary>
public abstract class Team : MonoBehaviour, ILootContainer, IReadOnlyTeam
{
	public TeamData data { get; protected set; } = new TeamData();


	public void Start()
	{
	}

	public void Update()
	{
		if (!MainController.Instance.Ready) return;

		if (data.IsDefeated)
		{ Debug.Log($"Team {data.TeamName} was defeated"); }

		UpdateLoot();
	}

	public bool Ready()
	{ return data.Ready; }



	// Database_______________________________________________________
	public void Lose()
	{ data.IsDefeated = true; }

	public void UpgradeBuildingArea()
	{
		GameObject panel = GameObject.FindGameObjectWithTag(PubNames.UpgradePanelTag);
		var text = panel.GetComponent<Text>();

		int upgradePrice;
		if (int.TryParse(text.text, out upgradePrice) && Pay(upgradePrice))
		{
			text.text = ((int)(upgradePrice * 1.5)).ToString();
			data.BuildingRadius += data.BuildingRadius * 0.3f;
			BuildingManager.ShowMessage("Building area has increased by 30%");
		}
		else
		{ BuildingManager.ShowMessage("Not enough gold"); }
	}

	/// <summary>
	/// Pays from the team's gold reserves
	/// </summary>
	/// <param name="price"></param>
	/// <returns>true if the payment was successful, otherwise returns false</returns>
	public bool Pay(int price)
	{
		if (data.LootCounter.ContainsKey(LootType.Gold) && data.LootCounter[LootType.Gold] >= price)
		{
			data.LootCounter[LootType.Gold] -= price;
			return true;
		}
		else
		{
			UIManager.Instance.UpdatePanel(UIManager.PanelNames.WarningP, "Not enough gold");
			return false;
		}
	}

	public void Earn(int money)
	{
		if (data.LootCounter.ContainsKey(LootType.Gold))
		{ data.LootCounter[LootType.Gold] += money; }
	}

	public void UpdateLoot()
	{
		Inventory updInv = new Inventory();
		updInv.InitInventory();

		foreach (var build in data.Buildings)
		{
			if (build is not ILootContainer)
			{ continue; }

			foreach (var loot in ((ILootContainer)build).GetTeamInventory()) // There might be more buildings that keeps loot
			{ updInv[loot.Key] += loot.Value; }
		}
		data.LootCounter = updInv;
	}

	public Team CreateBase()
	{
		var mb = Prefabs.MainBuildPref;
		var b = Creator.CreateBuilding(mb, data.BaseCenter).GetComponent<Building>();
		MapController.Instance.PlaceBuilding(b, this);

		if (Prefabs.WorkerPref == null) Debug.Log("Didn't find unit");
		int init_unit_count = 3;

		for (int i = 0; i < init_unit_count; i++)
		{ 
			var unit = Creator.CreateUnit(Prefabs.WorkerPref, 
				data.BaseCenter - new Vector3(15 + 5 * i, 0, 15 + 5 * i)).GetComponent<Unit>();
			if (unit != null) unit.Setup(data.ID);
		}
		return this;
		
	}

	/// <summary>
	/// Setup team. If there are troubles (base center is out of map, etc.) then method will return false, otherwise true.
	/// </summary>
	/// <param name="BasePos"></param>
	/// <param name="teamColor"></param>
	/// <param name="teamName"></param>
	/// <returns></returns>
	public virtual Team Setup(Vector2Int BasePos, Color teamColor, string teamName)
	{
		data.ID = TeamData.FreeID;
		TeamData.FreeID++;

		if (Map.IsOutOfMap(BasePos))
		{
			Destroy(this);
			Debug.Log("The base is out of map. Setup will be ignored.");
			return null;
		}
		data.BaseCenter = Map.MapToWorld(BasePos);
		data.TeamColor = teamColor;
		data.TeamName = teamName;
		return this;
	}
	// _______________________________________________________________



	#region Data transfering

	public string GetTeamName() => (string)data.TeamName.Clone();

	public int GetTeamID() => data.ID;

	public Color GetTeamColor() => data.TeamColor;

	public Vector3 GetTeamCenter() => data.BaseCenter; 

	public float GetTeamBuildingRadius() => data.BuildingRadius;

	public Inventory GetTeamInventory() => data.LootCounter;

	private T GetClosestTeamObj<T>(Vector3 pos, List<T> objList) where T : Component
	{
		if (objList.Count < 1) return null; 

		T obj = objList[0];

		foreach (var o in objList)
		{
			if (Vector3.Distance(obj.transform.position, pos) >
				Vector3.Distance(o.transform.position, pos))
			{ obj = o; }
		}
		return obj;
	}

	public Building GetClosestTeamBuild(Vector3 pos) => GetClosestTeamObj<Building>(pos, data.Buildings);

	public Unit GetClosestTeamUnit(Vector3 pos) => GetClosestTeamObj<Unit>(pos, data.Units);

	public void RegisterBuilding(Building building) 
	{ data.Buildings.Add(building); }

	public void RemoveBuilding(Building building) 
	{ data.Buildings.Remove(building); }


	public void RegisterUnit(Unit unit) 
	{ data.Units.Add(unit); }

	public void RemoveUnit(Unit unit) 
	{ data.Units.Remove(unit); }

	
	#endregion
}
