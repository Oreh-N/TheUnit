﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

public static class UnitManager
{
	// DATA_TRANSFERRING_______________________________________________________________

	public static string GetTeamName(int teamID)
	{
		Team t = GetTeam(teamID);
		if (t) return t.GetTeamName();
		return "";
	}
	public static Team GetTeam(int teamID)
	{
		if (!MainController.Instance.Ready) return null;

		Team t = MainController.Instance.GetTeam(teamID);
		if (t) return t;
		return null;
	}

	public static void RegisterUnit(Unit unit)
	{
		var t = MainController.Instance.GetTeam(unit.GetTeamID());
		if (t) t.RegisterUnit(unit);
	}
	public static string GetTeamName(Unit unit)
	{
		return unit.GetTeamName();
	}

	public static int GetPlayerTeamID()
	{
		return Player.Instance.GetTeamID();
	}
	// __________________________________________________________________________________
	public static void HitUnit(Unit injuredUnit, int damage)
	{
		injuredUnit.TakeDamage(damage);
	}
}
