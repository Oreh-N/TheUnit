﻿using UnityEngine;
using System;


public class HealerUnit : UnitSelf<HealerUnit>
{
	private new void Awake()
	{
		base.Awake();
		data.Name = "HealerUnit";
		data.CellType = MapSpace.Map.CellType.HealerUnit;
	}

	new void Start()
	{
		base.Start();
	}

	new void Update()
	{
		base.Update();
	}
	public override void Interact()
	{
		Debug.Log("Interact not ready yet. HealerUNIT");
	}

}