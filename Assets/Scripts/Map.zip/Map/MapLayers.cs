﻿using System.Collections.Generic;


namespace MapSpace
{
	public enum LayersNames { _LootL, _BuildingL, _InitL, _TreeL, _UnitL, _Invalid = 505 }   // Corresponds to _Maps to access them correctly

	public class MapLayers
	{
		class Layer<T>
		{
			public T[][,] l = new T[1][,];
		}

		Layer<ILootContainer> LootL = new Layer<ILootContainer>();
		Layer<Building>	BuildingL = new Layer<Building>();
		Layer<bool> InitL = new Layer<bool>();   // Removed after initialization
		Layer<bool> TreeL = new Layer<bool>();
		Layer<Unit> UnitL = new Layer<Unit>();

		public readonly int Count = 5;

		
		public void RemoveInitLayer() { InitL = null; }
	}
}
